// gerado por scripts/empacotar-extensao.mjs
window.NORDIC_CONFIG = {
  "supabaseUrl": "https://zdwqgkecojvqkpexglow.supabase.co",
  "supabaseKey": "sb_publishable_IDizhiRO1DgFtl6qh51lPA_JLYXDkF1",
  "servidores": [
    {
      "nome": "Produção",
      "url": "https://real-sales-ruby.vercel.app"
    }
  ]
};
